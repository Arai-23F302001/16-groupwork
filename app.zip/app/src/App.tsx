import DemoJP from "./DemoJP";
export default function App() {
  return <DemoJP />;
}
