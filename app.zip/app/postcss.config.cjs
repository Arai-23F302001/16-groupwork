module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},  // v4 新插件
    autoprefixer: {},
  },
};
